package lk.ijse.Model;

import lk.ijse.Db.DbConnection;
import lk.ijse.Dto.CustomerDto;
import lk.ijse.Dto.MedicineDto;
import lk.ijse.Dto.PrescriptionDto;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class MedicineModel {
    private MedicineDto dto;
    private Object MedicineDto;

    public static List<MedicineDto> getAllMedicine() throws SQLException {
        Connection connection = DbConnection.getInstance().getConnection();

        String sql = "SELECT * FROM medicine";
        PreparedStatement pstm = connection.prepareStatement(sql);

        ResultSet rst = pstm.executeQuery();

        ArrayList<MedicineDto> list = new ArrayList<>();

        while (rst.next()) {
            list.add(new MedicineDto(
                    rst.getString(1),
                    rst.getString(2),
                    rst.getString(3),
                    rst.getString(4),
                    rst.getString(5)));
        }
        return list;
    }



    public boolean saveMedicine(MedicineDto dto) throws SQLException {
        Connection connection = DbConnection.getInstance().getConnection();

        String sql = "INSERT INTO medicine VALUES (?,?,?,?,?)";
        PreparedStatement pstm = connection.prepareStatement(sql);

        pstm.setString(1, dto.getMedicine_id());
        pstm.setString(2, dto.getName());
        pstm.setString(3, dto.getType());
        pstm.setString(4, dto.getQty());
        pstm.setString(5, dto.getPrice());

        boolean isSaved = pstm.executeUpdate() > 0;

        return isSaved;

    }

    public boolean updateMedicine(MedicineDto dto) throws SQLException {
        Connection connection = DbConnection.getInstance().getConnection();

        String sql = "UPDATE medicine SET name = ?, type = ?, quantity = ?, price = ? WHERE medicine_id = ?";
        PreparedStatement pstm = connection.prepareStatement(sql);


        pstm.setString(1, dto.getName());
        pstm.setString(2, dto.getType());
        pstm.setString(3, dto.getQty());
        pstm.setString(4, dto.getPrice());
        pstm.setString(5, dto.getMedicine_id());

        boolean isSaved=pstm.executeUpdate()>0;
        return isSaved;

    }

    public MedicineDto searchMedicine(String id) throws SQLException {
        Connection connection = DbConnection.getInstance().getConnection();
        String sql = "SELECT * FROM medicine WHERE medicine_id = ?";
        PreparedStatement pstm = connection.prepareStatement(sql);

        pstm.setString(1, id);
        MedicineDto = null;
        ResultSet rst = pstm.executeQuery();
        if (rst.next()) {
            dto = new MedicineDto(rst.getString(1), rst.getString(2), rst.getString(3), rst.getString(4), rst.getString(5));
        }
        return dto;
    }

    public boolean deleteMedicine(String id) throws SQLException {
        Connection connection = DbConnection.getInstance().getConnection();
        String sql = "DELETE FROM medicine WHERE medicine_id = ?";
        try {
            PreparedStatement pstm = connection.prepareStatement(sql);
            pstm.setString(1, id);
            boolean isDeleted = pstm.executeUpdate() > 0;
            return isDeleted;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
    }


