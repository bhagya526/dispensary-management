package lk.ijse.Model;

public class UserModel {
}
