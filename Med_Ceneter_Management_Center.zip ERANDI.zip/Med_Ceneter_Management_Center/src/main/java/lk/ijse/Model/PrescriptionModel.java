package lk.ijse.Model;

import lk.ijse.Db.DbConnection;
import lk.ijse.Dto.CustomerDto;
import lk.ijse.Dto.PrescriptionDto;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class PrescriptionModel {

    public static boolean savePrescription(String id, String date, String description, String cust_id) throws SQLException {
        Connection connection = DbConnection.getInstance().getConnection();

        String sql = "INSERT INTO prescription VALUES (?,?,?,?)";
        PreparedStatement pstm = connection.prepareStatement(sql);

        pstm.setString(1, id);
        pstm.setString(2, date);
        pstm.setString(3, description);
        pstm.setString(4, cust_id);

        boolean isSaved = pstm.executeUpdate() > 0;

        return isSaved;

    }

    public static List<PrescriptionDto> getAllPrescription() throws SQLException {
        Connection connection = DbConnection.getInstance().getConnection();

        String sql = "SELECT * FROM customer";
        PreparedStatement pstm = connection.prepareStatement(sql);

        ResultSet rst = pstm.executeQuery();

        ArrayList<PrescriptionDto> list = new ArrayList<>();

        while(rst.next()){
            list.add(new PrescriptionDto(
                    rst.getString(1),
                    rst.getString(2),
                    rst.getString(3),
                    rst.getString(4)));
        }

        return list;
    }

    public boolean updatePrescription(PrescriptionDto dto) throws SQLException {
        Connection connection = DbConnection.getInstance().getConnection();

        String sql = "UPDATE prescription SET date = ?, description = ?, cust_id = ? WHERE prescription_id = ?";
        PreparedStatement pstm = connection.prepareStatement(sql);

        pstm.setString(1, dto.getDate());
        pstm.setString(2, dto.getDescription());
        pstm.setString(3, dto.getCust_id());
        pstm.setString(4, dto.getPres_id());

        boolean isSaved = pstm.executeUpdate() > 0;
        return isSaved;
    }

    public boolean deletePrescription(String id) throws SQLException {

        Connection connection = DbConnection.getInstance().getConnection();
        String sql = "DELETE FROM prescription WHERE prescription_id = ?";
        try {
            PreparedStatement pstm = connection.prepareStatement(sql);
            pstm.setString(1, id);
            boolean isDeleted = pstm.executeUpdate() > 0;
            return isDeleted;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
}