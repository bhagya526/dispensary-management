package lk.ijse.Model;

import lk.ijse.Db.DbConnection;
import lk.ijse.Dto.DoctorDto;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.concurrent.Callable;

public class DoctorModel {
    public boolean saveDoctor(DoctorDto dto) throws SQLException {
        Connection connection = DbConnection.getInstance().getConnection();

        String  sql="INSERT INTO doctor Values(?,?,?,?) ";
        PreparedStatement pstm=connection.prepareStatement(sql);

        pstm.setString(1,dto.getDoctor_id());
        pstm.setString(2,dto.getName());
        pstm.setString(3,dto.getEmail());
        pstm.setString(4,dto.getContact_no());

        boolean isSaved=pstm.executeUpdate()>0;
        return isSaved;
    }

    public boolean updateDoctor(DoctorDto docdto) throws SQLException {
        Connection connection = DbConnection.getInstance().getConnection();

        String sql="UPDATE doctor SET name=?,email=?,contact_no=? WHERE doctor_id=?";
        PreparedStatement pstm=connection.prepareStatement(sql);

        pstm.setString(1,docdto.getName());
        pstm.setString(2,docdto.getEmail());
        pstm.setString(3,docdto.getContact_no());
        pstm.setString(4,docdto.getDoctor_id());
        boolean isUpdated=pstm.executeUpdate()>0;
        return isUpdated;
    }


    public boolean deleteDoctor(String id) throws SQLException {
        Connection connection = DbConnection.getInstance().getConnection();
        String sql="DELETE FROM doctor WHERE doctor_id=?";
        try{
        PreparedStatement pstm=connection.prepareStatement(sql);
        pstm.setString(1,id);
        boolean isDeleted=pstm.executeUpdate()>0;
        return isDeleted;
    }catch (SQLException e){
            e.printStackTrace();
        }
        return false;
    }

    public DoctorDto searchDoctor(String id) throws SQLException {
        Connection connection = DbConnection.getInstance().getConnection();
        String sql="SELECT * FROM doctor WHERE doctor_id=?";
        PreparedStatement pstm=connection.prepareStatement(sql);
        pstm.setString(1,id);
        DoctorDto dto=null;
        ResultSet rst=pstm.executeQuery();
        if(rst.next()){
            dto=new DoctorDto(rst.getString(1),rst.getString(2),rst.getString(3),rst.getString(4));
        }
        return dto;
    }
}
