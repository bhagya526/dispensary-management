package lk.ijse.Model;

import javafx.collections.ObservableList;
import lk.ijse.Db.DbConnection;
import lk.ijse.Dto.CustomerDto;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class CustomerModel {
    public boolean savePatient(CustomerDto dto) throws SQLException {
        Connection connection = DbConnection.getInstance().getConnection();

        String sql = "INSERT INTO customer VALUES (?,?,?,?,?)";
        PreparedStatement pstm = connection.prepareStatement(sql);

        pstm.setString(1, dto.getCus_id());
        pstm.setString(2, dto.getName());
        pstm.setString(3, dto.getEmail());
        pstm.setString(4, dto.getAddress());
        pstm.setString(5, dto.getTel());

        boolean isSaved = pstm.executeUpdate() > 0;

        return isSaved;


    }

    public CustomerDto searchPatient(String id) throws SQLException
    {
        Connection connection = DbConnection.getInstance().getConnection();
        
        String sql = "SELECT * FROM customer WHERE cus_id = ?";
        PreparedStatement pstm = connection.prepareStatement(sql);
        
        pstm.setString(1, id);
        
        CustomerDto dto = null;
        
        ResultSet rst = pstm.executeQuery();
        
        if(rst.next()){
            dto = new CustomerDto(rst.getString(1), rst.getString(2), rst.getString(3), rst.getString(4), rst.getString(5));
        }
        
        return dto;
        
        
    }

    public boolean deletePatient(String id) throws SQLException {
        Connection connection = DbConnection.getInstance().getConnection();
        
        String sql = "DELETE FROM customer WHERE cus_id = ?";
        PreparedStatement pstm = connection.prepareStatement(sql);
        
        pstm.setString(1, id);
        
        boolean isDeleted = pstm.executeUpdate() > 0;
        
        return isDeleted;
    }

    public boolean updatePatient(CustomerDto dto) throws SQLException {
        Connection connection = DbConnection.getInstance().getConnection();

        String sql = "UPDATE customer SET name = ?, email = ?, address = ?, tel = ? WHERE cus_id = ?";
        PreparedStatement pstm = connection.prepareStatement(sql);

        pstm.setString(1, dto.getName());
        pstm.setString(2, dto.getEmail());
        pstm.setString(3, dto.getAddress());
        pstm.setString(4, dto.getTel());
        pstm.setString(5, dto.getCus_id());

        boolean isUpdated = pstm.executeUpdate() > 0;

        return isUpdated;
    }

    public List<CustomerDto> getAllPatients() throws SQLException {

        Connection connection = DbConnection.getInstance().getConnection();

        String sql = "SELECT * FROM customer";
        PreparedStatement pstm = connection.prepareStatement(sql);

        ResultSet rst = pstm.executeQuery();

        ArrayList<CustomerDto> list = new ArrayList<>();

        while(rst.next()){
            list.add(new CustomerDto(
                    rst.getString(1),
                    rst.getString(2),
                    rst.getString(3),
                    rst.getString(4),
                    rst.getString(5)));
        }

        return list;
    }
}
