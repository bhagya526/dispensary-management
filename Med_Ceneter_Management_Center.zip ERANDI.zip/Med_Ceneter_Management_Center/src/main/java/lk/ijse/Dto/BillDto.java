package lk.ijse.Dto;

import lombok.*;

@AllArgsConstructor
@NoArgsConstructor
@Setter
@Getter
@ToString
public class BillDto {

    private String billId;
    private String date;

    private String total;

    private String cus_id;
    private String order_id;
    private String user_id;

}
