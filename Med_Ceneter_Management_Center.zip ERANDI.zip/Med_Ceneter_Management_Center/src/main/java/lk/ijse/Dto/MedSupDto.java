package lk.ijse.Dto;

import lombok.*;

@AllArgsConstructor
@NoArgsConstructor
@Setter
@Getter
@ToString
public class MedSupDto {
    private String medicine_id;
    private String sup_id;
}
