package lk.ijse.Dto;

import lombok.*;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@ToString
public class DoctorDto {
    private String doctor_id;
    private String name;
    private String email;
    private  String contact_no;
}
