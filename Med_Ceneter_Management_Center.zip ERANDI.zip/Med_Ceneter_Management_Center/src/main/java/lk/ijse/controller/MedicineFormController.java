package lk.ijse.controller;

import com.jfoenix.controls.JFXTextField;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.scene.control.Alert;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import lk.ijse.Dto.CustomerDto;
import lk.ijse.Dto.MedicineDto;
import lk.ijse.Dto.tm.MedicineTm;
import lk.ijse.Dto.tm.PatientTm;
import lk.ijse.Model.MedicineModel;

import java.awt.*;
import java.sql.SQLException;
import java.util.List;

public class MedicineFormController {
    public JFXTextField MedicineId;
    public JFXTextField Name;
    public JFXTextField Type;
    public JFXTextField Quantity;
    public JFXTextField Price;
    public TableView TblMedicine;
    public TableColumn ColId;
    public TableColumn ColName;
    public TableColumn ColQuantity;
    public TableColumn ColPrice;
    public TableColumn ColType;

    private MedicineModel model = new MedicineModel();

    public void initialize(){
        setCellValueFactory();
        loadAllMedicine();
    }

    private void loadAllMedicine() {
        ObservableList<MedicineTm> oblist = FXCollections.observableArrayList();
        try {
            List<MedicineDto> dtos = MedicineModel.getAllMedicine();

            for (MedicineDto dto : dtos) {
                oblist.add(new MedicineTm(
                        dto.getMedicine_id(),
                        dto.getName(),
                        dto.getType(),
                        dto.getQty(),
                        dto.getPrice()));
            }
            TblMedicine.setItems(oblist);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void setCellValueFactory() {
        ColId.setCellValueFactory(new PropertyValueFactory<>("MedicineId"));
        ColName.setCellValueFactory(new PropertyValueFactory<>("Name"));
        ColType.setCellValueFactory(new PropertyValueFactory<>("Type"));
        ColQuantity.setCellValueFactory(new PropertyValueFactory<>("Quantity"));
        ColPrice.setCellValueFactory(new PropertyValueFactory<>("Price"));

    }

    public void SaveOnAction(ActionEvent actionEvent) throws SQLException {

        String id = MedicineId.getText();
        String name = Name.getText();
        String type = Type.getText();
        String qty = Quantity.getText();
        String price=Price.getText();

        MedicineDto dto=new MedicineDto(id,name,type,qty,price);
        boolean isSaved=model.saveMedicine(dto);

        if(isSaved){

            new Alert(Alert.AlertType.INFORMATION,"Saved").show();
            clearFields();
        } else {
            new Alert(Alert.AlertType.WARNING,"Try Again").show();
        }



    }

    public void UpdateOnAction(ActionEvent actionEvent) throws SQLException{
        String id = MedicineId.getText();
        String name = Name.getText();
        String type = Type.getText();
        String qty = Quantity.getText();
        String price = Price.getText();

        MedicineDto dto=new MedicineDto(id,name,type,qty,price);

        boolean isUpdated=model.updateMedicine(dto);
         if(isUpdated) {
             System.out.println("Updated");
             new Alert(Alert.AlertType.CONFIRMATION, "Updated").show();
             clearFields();
         }
        else{
        System.out.println("Not Updated");
        new Alert(Alert.AlertType.INFORMATION, "Updated").show();
    }

    }

    public void DeleteOnAction(ActionEvent actionEvent) throws SQLException {
        String id = MedicineId.getText();
        boolean isDeleted = model.deleteMedicine(id);
        if(isDeleted){
            System.out.println("Deleted");
            new Alert(Alert.AlertType.CONFIRMATION, "Deleted").show();
            clearFields();
        }
        else{
            System.out.println("Not Deleted");
            new Alert(Alert.AlertType.INFORMATION, "Deleted").show();
        }
    }





    public void ClearOnAction(ActionEvent actionEvent) {
        clearFields();
    }

    private void clearFields() {
        MedicineId.clear();
        Name.clear();
        Type.clear();
        Quantity.clear();
        Price.clear();
    }



    public void idOInAction(ActionEvent actionEvent) throws SQLException {
        String id = MedicineId.getText();

        MedicineDto dto = model.searchMedicine(id);

        if (dto == null) {
            System.out.println("Not Found");
            new Alert(Alert.AlertType.INFORMATION, "Not Found").show();
        } else {
            new Alert(Alert.AlertType.INFORMATION, "Found").show();

            Name.setText(dto.getName());
            Type.setText(dto.getType());
            Quantity.setText(dto.getQty());
            Price.setText(dto.getPrice());

        }


    }
}




