package lk.ijse.controller;

import com.jfoenix.controls.JFXTextField;
import javafx.event.ActionEvent;
import javafx.scene.control.Alert;
import lk.ijse.Dto.DoctorDto;
import lk.ijse.Dto.MedicineDto;
import lk.ijse.Model.DoctorModel;

import javax.xml.namespace.QName;
import java.sql.SQLException;

public class DoctorFormController {
    public JFXTextField docId;
    public JFXTextField Name;
    public JFXTextField Email;
    public JFXTextField ContactNo;
private DoctorModel doctorModel=new DoctorModel();

    public void SaveOnAction(ActionEvent actionEvent) throws SQLException {
        String id = docId.getText();
        String name = Name.getText();
        String email = Email.getText();
        String Con_no = ContactNo.getText();

        DoctorDto docdto = new DoctorDto(id, name, email, Con_no);

        boolean dto=doctorModel.saveDoctor(docdto);
        if(dto){
            new Alert(Alert.AlertType.CONFIRMATION,"Saved").show();
        }else{
            new Alert(Alert.AlertType.WARNING,"Try Again").show();
        }


    }

    public void UpdateOnAction(ActionEvent actionEvent) throws SQLException {
        String id = docId.getText();
        String name = Name.getText();
        String email = Email.getText();
        String Con_no = ContactNo.getText();
        DoctorDto docdto = new DoctorDto(id, name, email, Con_no);

        boolean isUpdated=doctorModel.updateDoctor(docdto);
        if(isUpdated){
            System.out.println("Updated");
            new Alert(Alert.AlertType.CONFIRMATION,"Updated").show();
        }else {
            System.out.println("not Updated");
            new Alert(Alert.AlertType.WARNING,"Try Again").show();
        }

    }

    public void DeleteOnAction(ActionEvent actionEvent) throws SQLException {
        String id = docId.getText();
        boolean isDeleted = doctorModel.deleteDoctor(id);
        if(isDeleted){
            System.out.println("Deleted");
            new Alert(Alert.AlertType.CONFIRMATION,"Deleted").show();
            clearFields();
        }else{
            System.out.println("Not Deleted");
            new Alert(Alert.AlertType.WARNING,"Try Again").show();
            clearFields();
        }
    }

    public void ClearOnAction(ActionEvent actionEvent) {
        clearFields();
    }

    private void clearFields() {
        docId.clear();
        Name.clear();
        Email.clear();
        ContactNo.clear();
    }

    public void DoctorOnAction(ActionEvent actionEvent) throws SQLException {
        String id = docId.getText();

        DoctorDto dto = doctorModel.searchDoctor(id);

        if (dto == null) {
            System.out.println("Not Found");
            new Alert(Alert.AlertType.INFORMATION, "Not Found").show();
        } else {
            new Alert(Alert.AlertType.INFORMATION, "Found").show();


            Name.setText(dto.getName());
            Email.setText(dto.getEmail());
            ContactNo.setText(dto.getContact_no());

        }
    }
}
