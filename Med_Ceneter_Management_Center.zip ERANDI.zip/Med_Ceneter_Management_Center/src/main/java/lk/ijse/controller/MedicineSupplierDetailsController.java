package lk.ijse.controller;

public class MedicineSupplierDetailsController {
}
