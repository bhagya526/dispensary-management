package lk.ijse.controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;

public class DashboardControllerFormController {
    public AnchorPane changePain;
    public AnchorPane root;

    public void patientOnAction(ActionEvent actionEvent) throws IOException {
        URL resourse = getClass().getResource("/view/patient_form.fxml");
        assert resourse != null;
        Parent load = FXMLLoader.load(resourse);
        changePain.getChildren().clear();
        changePain.getChildren().add(load);
    }

    public void medicineOnAction(ActionEvent actionEvent) throws IOException {
        URL resourse = getClass().getResource("/view/MedicineForm.fxml");
        assert resourse != null;
        Parent load = FXMLLoader.load(resourse);
        changePain.getChildren().clear();
        changePain.getChildren().add(load);
    }

    public void signoutOnAction(ActionEvent actionEvent) throws IOException {

        Parent parent = FXMLLoader.load(this.getClass().getResource("/view/LoginPageForm.fxml"));
        Scene scene = new Scene(parent);

        root.getChildren().clear();
        Stage stage = (Stage) root.getScene().getWindow();

        stage.setScene(scene);

    }

    public void prescriptionOnaction(ActionEvent actionEvent) throws IOException {
        URL resourse = getClass().getResource("/view/PrescriptionForm.fxml");
        assert resourse != null;
        Parent load = FXMLLoader.load(resourse);
        changePain.getChildren().clear();
        changePain.getChildren().add(load);
    }

    public void doctorOnAction(ActionEvent actionEvent) throws IOException {
        URL resourse = getClass().getResource("/view/DoctorForm.fxml");
        assert resourse != null;
        Parent load = FXMLLoader.load(resourse);
        changePain.getChildren().clear();
        changePain.getChildren().add(load);
    }

    public void OrdersOnAction(ActionEvent actionEvent) throws IOException {
        URL resourse = getClass().getResource("/view/OrdersForm.fxml");
        assert resourse != null;
        Parent load = FXMLLoader.load(resourse);
        changePain.getChildren().clear();
        changePain.getChildren().add(load);
    }
}
