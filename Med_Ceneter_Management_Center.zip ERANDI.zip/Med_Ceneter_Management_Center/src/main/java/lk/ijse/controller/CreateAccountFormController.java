package lk.ijse.controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import lk.ijse.Model.UserModel;

import java.io.IOException;

public class CreateAccountFormController {
    public AnchorPane rootnode;
    public TextField FirstName;
    public TextField SecondName;
    public TextField Address;
    public TextField TelNum;
    public TextField Email;

    private UserModel model = new UserModel();


    public void backOnAction(ActionEvent actionEvent) throws IOException {
        Parent parent = FXMLLoader.load(this.getClass().getResource("/view/LoginPageForm.fxml"));
        Scene scene = new Scene(parent);

        rootnode.getChildren().clear();
        Stage stage = (Stage) rootnode.getScene().getWindow();

        stage.setScene(scene);
    }

    public void signUpOnAction(ActionEvent actionEvent) throws IOException {

        String firstName = FirstName.getText();
        String secondName = SecondName.getText();
        String address = Address.getText();
        String telNum = TelNum.getText();
        String email = Email.getText();



    }
}
